<?php
if ($_POST['login_pwd'] == '29LiveForever99')
	echo 'Welcome to the Dashboard!';
else
header
('Location:login.html');
?>

